const express = require('express');
const cors = require('cors');
const fs = require('fs');

const EXTENSIONS_DIR = '../charts-s3';

const app = express();
app.use(cors());

app.get('/', (req, res) => res.send('Holi!'))

app.get('/charts/extensions/all', (req, res) =>{
    fs.readdir(EXTENSIONS_DIR, (err, files) => {
        if(err) return res.send('pailas');

        res.json(files.filter(file => !file.startsWith('.')));
    })
});

app.get('/charts/extensions/:extensionName/:file', (req, res) => {
    const {extensionName, file} = req.params;
    const DIR = EXTENSIONS_DIR + '/' + extensionName + '/' + file;

    fs.readFile(DIR, 'utf-8', (err, file) => {
        if(err) return res.send('pailas');

        res.set('Content-Type', 'application/javascript');
        res.send(file);
    });
    
})


app.get('/charts/extensions/:extensionName', (req, res) => {
    const DIR = EXTENSIONS_DIR + '/' + req.params.extensionName;

    fs.readdir(DIR, (err, files) => {
        if(err) return res.send('pailas');

        res.send(JSON.stringify(files))
    })
})


app.listen(3000, () => console.log('running in port 3000'));
